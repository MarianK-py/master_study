import numpy as np
import sys

def load_data(filename):
  f = open(filename)
  n, m = map(int, next(f).strip().split())

  X = []
  y = []
  for l in f:
    its = l.strip().split()
    k = int(its[0])
    row = {}
    for i in range(k):
      row[int(its[i*2+1])] = float(its[i*2+2])
    y.append(float(its[-1]))
    X.append(row)

  return n, m, X, y

# Doprogramujte tuto funkciu
# Nech vrati dvojicu (theta, trenovacia chyba)
# X je list dictov, kde kazdy dict ma ako kluc index nenuloveho miesta a hodnotu samotnu hodnotu na
# tom mieste, napr.:
# {0: 4.2, 47: 2.3} znamena, ze na indexe 0 mame hodnotu 4.2 a na indexe 47 mame hodnotu 2.3 a
# ostatne su nulove
#
# Fill out this function
# It should return tuple of (theta, traning error)
# X is list of dictionaries, where each dictionary has key the index of non zero element
# and value the value on that place, for example
# {0: 4.2, 47: 2.3} means, that on index 0 we have value 4.2 and on index 47 we have value 2.3 and
# other elements are zero
def fit(n, m, X, y):
  pass

n, m, X, y = load_data(sys.argv[1])
theta, train_error = fit(n, m, X, y)

print("Training error", train_error)
