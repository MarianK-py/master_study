import sys
import numpy as np
import scipy

def load(filename):
  f = open(filename)
  X = []
  Y = []
  for l in f:
    its = l.strip().split()
    x = float(its[0])
    y = float(its[1])
    X.append(x)
    Y.append(y)

  return np.array(X), np.array(Y)

# Tuto funkciu treba doprogramovat
# X - 1rozmerne pole vstupov
# Y - 1rozmerne pole ocakavanych vystupov
#
# Fill out this function
# X - 1 dimensional array of inputs
# Y - 1 dimensional array of expected outputs
def fit(X, Y):
  # Vraciame premenne v poradi A, B
  # We returns values in order A, B
  return 42, 47

# Pomocna funkcia (pre dane, X, A, B vrati predikcie)
# Helper function, for given A, B returns predictions
def predict(X, A, B):
  return A * np.exp(-X/B)

X, Y = load(sys.argv[1])

A, B = fit(X, Y)

print ("A: %.3f, B: %.3f" % (A, B))
